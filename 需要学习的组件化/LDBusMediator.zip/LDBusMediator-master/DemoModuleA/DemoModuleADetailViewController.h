//
//  DemoModuleADetailViewController.h
//  LDBusMediator
//
//  Created by 庞辉 on 4/19/16.
//  Copyright © 2016 casa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoModuleADetailViewController : UIViewController

@property (nonatomic, strong, readonly) UILabel *valueLabel;
@property (nonatomic, strong, readonly) UIImageView *imageView;

@end
