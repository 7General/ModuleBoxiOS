//
//  ModuleAXXXItem.h
//  LDBusMediator
//
//  Created by 庞辉 on 4/19/16.
//  Copyright © 2016 casa. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ModuleAXXXItemPrt.h"

/**
 * @class ModuleAXXXItem
 *  模块内部的协议对象构造
 */
@interface ModuleAXXXItem : NSObject<ModuleAXXXItemPrt>{

}

@end
